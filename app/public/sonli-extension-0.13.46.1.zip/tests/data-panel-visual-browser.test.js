const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const { createServer } = require("node:http");
const { existsSync, readFileSync } = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const { chromium } = require("playwright-core");

const rootDir = path.resolve(__dirname, "..", "..");
const fixturePath = "/extension/tests/fixtures/data-panel-visual-browser.fixture.html";
const cleanupChildMode = process.env.JZ_BROWSER_TEST_CHILD_MODE === "forced-launch-failure";

function runCleanupChild() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [__filename], {
      env: {
        ...process.env,
        JZ_BROWSER_TEST_CHILD_MODE: "forced-launch-failure",
        JZ_BROWSER_TEST_FORCE_LAUNCH_FAILURE: "1",
      },
      stdio: ["ignore", "pipe", "pipe"],
    });
    let output = "";
    const timeout = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("cleanup child did not exit within 5 seconds"));
    }, 5_000);
    child.stdout.on("data", (chunk) => {
      output += chunk;
    });
    child.stderr.on("data", (chunk) => {
      output += chunk;
    });
    child.once("error", (error) => {
      clearTimeout(timeout);
      reject(error);
    });
    child.once("exit", (code, signal) => {
      clearTimeout(timeout);
      resolve({ code, output, signal });
    });
  });
}

function resolveBrowserPath() {
  const candidates = [
    process.env.JZ_BROWSER_PATH,
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    process.env.PROGRAMFILES && path.join(process.env.PROGRAMFILES, "Google/Chrome/Application/chrome.exe"),
    process.env["PROGRAMFILES(X86)"] && path.join(process.env["PROGRAMFILES(X86)"], "Google/Chrome/Application/chrome.exe"),
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
  ].filter(Boolean);
  const executablePath = candidates.find((candidate) => existsSync(candidate));
  assert.ok(
    executablePath,
    `No Chrome/Chromium executable found. Set JZ_BROWSER_PATH to run ${path.basename(__filename)}.`,
  );
  return executablePath;
}

function startFixtureServer() {
  const contentTypes = {
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
  };
  const server = createServer((request, response) => {
    const requestPath = new URL(request.url, "http://127.0.0.1").pathname;
    const filePath = path.resolve(rootDir, `.${decodeURIComponent(requestPath)}`);
    if (!filePath.startsWith(`${rootDir}${path.sep}`)) {
      response.writeHead(403).end();
      return;
    }
    try {
      const contents = readFileSync(filePath);
      response.writeHead(200, { "content-type": contentTypes[path.extname(filePath)] || "application/octet-stream" });
      response.end(contents);
    } catch {
      response.writeHead(404).end("not found");
    }
  });
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => resolve(server));
  });
}

function gridColumnCount(columns) {
  return columns.trim().split(/\s+/).filter(Boolean).length;
}

async function closeQuietly(label, close, cleanupErrors) {
  try {
    await close();
    return true;
  } catch (error) {
    cleanupErrors.push(new Error(`Could not close ${label}`, { cause: error }));
    return false;
  }
}

function closeServer(server) {
  return new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
}

async function runBrowserFixture({
  forceLaunchFailure = process.env.JZ_BROWSER_TEST_FORCE_LAUNCH_FAILURE === "1",
  onServerClosed,
} = {}) {
  let server;
  let browser;
  let context;
  let page;
  let primaryError;
  try {
    server = await startFixtureServer();
    const address = server.address();
    if (forceLaunchFailure) {
      throw new Error("forced browser launch failure");
    }
    browser = await chromium.launch({ executablePath: resolveBrowserPath(), headless: true });
    context = await browser.newContext({ viewport: { width: 720, height: 900 } });
    page = await context.newPage();

    await page.goto(`http://127.0.0.1:${address.port}${fixturePath}`);
    await page.waitForSelector('.ozon-helper-data-panel [data-field="sales30d"]');
    await page.evaluate(() => window.__setPanelFixtureWidth(640));

    const wide = await page.evaluate(() => {
      const panel = document.querySelector(".ozon-helper-data-panel");
      const hero = panel.querySelector(".oh-hero-section");
      return {
        background: getComputedStyle(panel).backgroundColor,
        columns: getComputedStyle(hero).gridTemplateColumns,
        backgrounds: [...panel.querySelectorAll(".oh-hero-stat")].map((stat) => getComputedStyle(stat).backgroundColor),
        fields: [...panel.querySelectorAll("[data-field]")].map((field) => field.getAttribute("data-field")),
        actions: [...panel.querySelectorAll("[data-action]")].map((action) => action.getAttribute("data-action")),
      };
    });
    assert.equal(wide.background, "rgb(255, 255, 255)");
    assert.equal(gridColumnCount(wide.columns), 4);
    assert.deepEqual(wide.backgrounds, Array(4).fill("rgb(242, 247, 255)"));
    for (const field of ["sales30d", "createDate", "heroFollow", "heroSize", "category", "sku", "returnRate", "rating", "dimensions", "volume", "weight"]) {
      assert.ok(wide.fields.includes(field), `missing rendered field ${field}`);
    }
    for (const action of ["open-field-settings", "follow-sell", "edit-list", "collect-one"]) {
      assert.ok(wide.actions.includes(action), `missing rendered action ${action}`);
    }

    await page.locator('.ozon-helper-data-panel [data-action="open-field-settings"]').click();
    await page.waitForSelector(".jz-fieldset-mask");
    await page.locator(".jz-fieldset-mask").evaluate((mask) => mask.remove());

    await page.locator('.ozon-helper-data-panel [data-action="toggle-section"]').first().click();
    assert.equal(
      await page.locator(".ozon-helper-sidebar-section").first().evaluate((section) => section.classList.contains("is-collapsed")),
      true,
      "section action should use the existing delegated toggle",
    );

    const logoFallback = await page.evaluate(() => {
      const panel = document.querySelector(".ozon-helper-data-panel");
      window.jzRenderProductPanelV2(panel, { sku: "123456789" });
      panel.querySelector(".ozon-helper-sidebar-brand-mark img").dispatchEvent(new Event("error"));
      const mark = panel.querySelector(".ozon-helper-sidebar-brand-mark");
      return {
        display: getComputedStyle(mark).display,
        title: panel.querySelector(".ozon-helper-sidebar-brand-title").textContent.trim(),
      };
    });
    assert.equal(logoFallback.display, "none");
    assert.equal(logoFallback.title, "ozon 粽子 · 选品助手");

    const skeletonStatus = await page.evaluate(() => {
      const panel = document.querySelector(".ozon-helper-data-panel");
      window.jzRenderPanelSkeleton(panel);
      return panel.querySelector(".ozon-helper-sidebar-brand-status").textContent.trim();
    });
    assert.equal(skeletonStatus, "正在加载商品数据");

    const narrowColumns = await page.evaluate(() => {
      const panel = document.querySelector(".ozon-helper-data-panel");
      window.__setPanelFixtureWidth(400);
      window.jzRenderProductPanelV2(panel, { sku: "123456789" });
      return getComputedStyle(panel.querySelector(".oh-hero-section")).gridTemplateColumns;
    });
    assert.equal(gridColumnCount(narrowColumns), 2);
  } catch (error) {
    primaryError = error;
    throw error;
  } finally {
    const cleanupErrors = [];
    await closeQuietly("page", () => page?.close(), cleanupErrors);
    await closeQuietly("browser context", () => context?.close(), cleanupErrors);
    await closeQuietly("browser", () => browser?.close(), cleanupErrors);
    const serverClosed = await closeQuietly("fixture server", () => server ? closeServer(server) : undefined, cleanupErrors);
    if (serverClosed && server && onServerClosed) {
      onServerClosed();
    }
    if (cleanupErrors.length && !primaryError) {
      throw new AggregateError(cleanupErrors, "Browser fixture cleanup failed");
    }
  }
}

async function verifyForcedLaunchFailureCleanup() {
  let serverClosed = false;
  await assert.rejects(
    runBrowserFixture({
      onServerClosed: () => {
        serverClosed = true;
      },
    }),
    /forced browser launch failure/,
  );
  assert.equal(serverClosed, true, "fixture server should close after launch setup fails");
  process.stdout.write("forced launch cleanup complete\n");
}

if (cleanupChildMode) {
  void verifyForcedLaunchFailureCleanup().catch((error) => {
    process.stderr.write(`${error.stack}\n`);
    process.exitCode = 1;
  });
} else {
test("data panel browser fixture preserves production contracts and responsive visual hierarchy", async () => {
  await runBrowserFixture();
});

test("data panel browser fixture releases its server after browser launch fails", async () => {
  const result = await runCleanupChild();
  assert.equal(result.signal, null, result.output);
  assert.equal(result.code, 0, result.output);
  assert.match(result.output, /forced launch cleanup complete/);
});
}
